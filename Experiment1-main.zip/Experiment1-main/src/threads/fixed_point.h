#ifndef __THREAD_FIXED_POINT_H
#define __THREAD_FIXED_POINT_H

/* Basic definitions of fixed point. */
typedef int fixed_t;
/* 16 LSB used for fractional part. */
#define fp 16
/* Convert a value to fixed-point value. */
#define convert_to_fixed_point(a) ((fixed_t)(a << fp))
/* Add two fixed-point value. */
#define add(a,b) (a + b)
/* Add a fixed-point value a and an int value b. */
#define add_mix(a,b) (a + (b << fp))
/* Substract two fixed-point value. */
#define sub(a,b) (a - b)
/* Substract an int value b from a fixed-point value a */
#define sub_mix(a,b) (a - (b << fp))
/* Multiply a fixed-point value a by an int value b. */
#define mult_mix(a,b) (a * b)
/* Divide a fixed-point value a by an int value b. */
#define div_mix(a,b) (a / b)
/* Multiply two fixed-point value. */
#define mult(a,b) ((fixed_t)(((int64_t) a) * b >> fp))
/* Divide two fixed-point value. */
#define div_mix(a,b) ((fixed_t)((((int64_t) a) << fp) / b))
/* Get integer part of a fixed-point value. */
#define int_part(a) (a >> fp)
/* Get rounded integer of a fixed-point value. */
#define round(a) (a >= 0 ? ((a + (1 << (fp - 1))) >> fp) \
        : ((a - (1 << (fp - 1))) >> fp))
 
#endif /* thread/fixed_point.h */
