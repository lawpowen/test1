#ifndef __THREAD_FIXED_POINT_H
#define __THREAD_FIXED_POINT_H

/* Basic definitions of fixed point. */
typedef int fixed_t;
/* 16 LSB used for fractional part. */
#define f 16
/* Convert a value to fixed-point value. */
#define convert_to_fixed_point(a) ((fixed_t)(a << f))
/* Add two fixed-point value. */
#define add(a,b) (a + b)
/* Add a fixed-point value a and an int value b. */
#define add_mix(a,b) (a + (b << f))
/* Substract two fixed-point value. */
#define sub(a,b) (a - b)
/* Substract an int value b from a fixed-point value a */
#define sub_mix(a,b) (a - (b << f))
/* Multiply a fixed-point value a by an int value b. */
#define mult_mix(a,b) (a * b)
/* Divide a fixed-point value a by an int value b. */
#define div_mix(a,b) (a / b)
/* Multiply two fixed-point value. */
#define mult(a,b) ((fixed_t)(((int64_t) a) * b >> f))
/* Divide two fixed-point value. */
#define div(a,b) ((fixed_t)((((int64_t) a) << f) / b))
/* Get integer part of a fixed-point value. */
#define int_part(a) (a >> f)
/* Get rounded integer of a fixed-point value. */
#define round(a) (a >= 0 ? ((a + (1 << (f - 1))) >> f) \
        : ((a - (1 << (f - 1))) >> f))
 
#endif /* thread/fixed_point.h */
